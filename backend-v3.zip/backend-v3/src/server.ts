import 'dotenv/config'
import Fastify from 'fastify'
import helmet from '@fastify/helmet'
import cors from '@fastify/cors'

import { env } from '@/env.js'
import { initPrisma } from '@/lib/prisma'

// plugins/rutas migradas
import { live, ready, health } from '@/routes/health.js'
import authPlugin from '@/plugins/auth'           // decora app.auth (preHandler)
import authRoutes from '@/routes/auth'            // /auth/login, /auth/logout, /auth/me (usa preHandler en /me)
import usersRoutes from '@/routes/users'          // /users, /users/:id (preHandlers internos)
import usersMeRoutes from '@/routes/users.me'     // /users/me (preHandler interno)

await initPrisma()

const app = Fastify({ logger: true })

// Seguridad + CORS
await app.register(helmet)
await app.register(cors, {
  origin: true,            // o un array/dom específico
  credentials: true
})

// Rutas públicas
app.get('/api/v1/live', live)
app.get('/api/v1/ready', ready)
app.get('/api/v1/health', health)
await app.register(authPlugin)                       // agrega app.auth
await app.register(authRoutes, { prefix: '/api/v1' })// /api/v1/auth/*

// Rutas protegidas (scope con preHandler global)
await app.register(async (sub) => {
  sub.addHook('preHandler', sub.auth)               // exige Authorization: Bearer ...
  await sub.register(usersMeRoutes)                 // /users/me
  await sub.register(usersRoutes)                   // /users y /users/:id
}, { prefix: '/api/v1' })

// raíz simple
app.get('/', async () => ({ ok: true }))

await app.listen({ port: env.PORT, host: '0.0.0.0' })