import 'dotenv/config'
import { z } from 'zod'

const msLike = z.string().regex(/^\d+(ms|s|m|h|d|w)$/i, 'Formato tipo 15m, 2h, 7d')

const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().max(65535).default(3000),

  DATABASE_URL: z.string().min(1, 'DATABASE_URL requerida'),
  
  JWT_SECRET: z.string().min(1),
  JWT_EXPIRES: z.union([z.coerce.number().int().positive(), msLike]).default('15m'),

  JWT_REFRESH_SECRET: z.string().min(1),
  JWT_REFRESH_EXPIRES: z.union([z.coerce.number().int().positive(), msLike]).default('30d'),

  COOKIE_REFRESH_NAME: z.string().default('refresh_token'),
  COOKIE_DOMAIN: z.string().optional(),
})

const parsed = EnvSchema.safeParse(process.env)

if (!parsed.success) {
  const tree = z.treeifyError(parsed.error)
  console.dir(tree, { depth: null })
  process.exit(1)
}
export const env = parsed.data
