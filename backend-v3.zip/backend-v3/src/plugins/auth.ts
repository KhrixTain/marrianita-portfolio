// src/plugins/auth.ts
import fp from 'fastify-plugin'
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify'
import { verifyAccessToken } from '@/auth/jwt.js'

async function authHook(request: FastifyRequest, reply: FastifyReply) {
  const auth = request.headers['authorization'] ?? ''
  const token = typeof auth === 'string' && auth.startsWith('Bearer ')
    ? auth.slice(7)
    : undefined

  if (!token) return reply.code(401).send({ error: 'unauthenticated' })

  try {
    const payload = verifyAccessToken<{ sub: string }>(token)
    request.user = { id: payload.sub }
  } catch {
    return reply.code(401).send({ error: 'invalid_token' })
  }
}

export default fp(async function authPlugin(app: FastifyInstance) {
  // Exponemos como utilidad para usar en rutas: { preHandler: app.auth }
  app.decorate('auth', authHook)
}, { name: 'auth-plugin' })

declare module 'fastify' {
  interface FastifyInstance {
    auth: (req: FastifyRequest, rep: FastifyReply) => Promise<void> | void
  }
}
