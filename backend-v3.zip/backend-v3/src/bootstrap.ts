// registra paths del tsconfig para que funcione "@/..."
import 'tsconfig-paths/register'

// arranca tu server
import './server'