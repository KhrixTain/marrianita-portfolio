// src/lib/prisma.ts
import { Prisma, PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient }

// Tip correcto para la opción `log`:
const log: (Prisma.LogLevel | Prisma.LogDefinition)[] =
  process.env.NODE_ENV === 'development'
    ? ['query', 'warn', 'error']
    : ['error']

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log
    // datasources: { db: { url: process.env.DATABASE_URL } } // opcional
  })

export async function initPrisma() {
  await prisma.$connect()
}

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma
}

const stopSignals: NodeJS.Signals[] = ['SIGINT', 'SIGTERM']
for (const sig of stopSignals) {
  process.on(sig, async () => {
    try {
      await prisma.$disconnect()
    } finally {
      process.exit(0)
    }
  })
}

export default prisma
