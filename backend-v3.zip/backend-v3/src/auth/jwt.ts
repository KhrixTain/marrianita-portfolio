// src/auth/jwt.ts
import jwt, { type JwtPayload, type Algorithm, type SignOptions, type Secret } from 'jsonwebtoken'
import { env } from '@/env.js'

export type AppJwtPayload = JwtPayload & {
  sub: string
  email: string
  roles?: string[]
}

const accessSecret: Secret = env.JWT_SECRET
const refreshSecret: Secret = env.JWT_REFRESH_SECRET

type Expires = SignOptions['expiresIn']
const accessExpDefault: Expires  = env.JWT_EXPIRES as any
const refreshExpDefault: Expires = env.JWT_REFRESH_EXPIRES as any

export function signAccessToken(payload: AppJwtPayload, expiresIn: Expires = accessExpDefault) {
  const opts: SignOptions = { algorithm: 'HS256' as Algorithm, expiresIn }
  return jwt.sign(payload, accessSecret, opts)
}
export function verifyAccessToken<T = AppJwtPayload>(token: string): T {
  return jwt.verify(token, accessSecret) as T
}

export function signRefreshToken(payload: AppJwtPayload, expiresIn: Expires = refreshExpDefault) {
  const opts: SignOptions = { algorithm: 'HS256' as Algorithm, expiresIn }
  return jwt.sign(payload, refreshSecret, opts)
}
export function verifyRefreshToken<T = AppJwtPayload>(token: string): T {
  return jwt.verify(token, refreshSecret) as T
}