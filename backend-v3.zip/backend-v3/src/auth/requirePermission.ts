// src/middlewares/permissions.ts
import type { FastifyReply, FastifyRequest } from 'fastify'
import { hasPermission } from '@/auth/permissions.js'

// Requiere un permiso (RBAC)
export function requirePermission(key: string) {
  return async (request: FastifyRequest, reply: FastifyReply) => {
    const userId = request.user?.id
    if (!userId) return reply.code(401).send({ error: 'unauthenticated' })

    const ok = await hasPermission(userId, key)
    if (!ok) return reply.code(403).send({ error: 'forbidden', missing: key })
  }
}

// Permite si el usuario tiene **alguno** de los permisos
export function requireAny(keys: string[]) {
  return async (request: FastifyRequest, reply: FastifyReply) => {
    const userId = request.user?.id
    if (!userId) return reply.code(401).send({ error: 'unauthenticated' })

    for (const k of keys) {
      if (await hasPermission(userId, k)) return
    }
    return reply.code(403).send({ error: 'forbidden', missingAnyOf: keys })
  }
}

// Requiere **todos** los permisos
export function requireAll(keys: string[]) {
  return async (request: FastifyRequest, reply: FastifyReply) => {
    const userId = request.user?.id
    if (!userId) return reply.code(401).send({ error: 'unauthenticated' })

    for (const k of keys) {
      if (!(await hasPermission(userId, k))) {
        return reply.code(403).send({ error: 'forbidden', missing: k })
      }
    }
  }
}

// Permite si es el owner (params.id) **o** tiene el permiso dado
export function requireSelfOr(permissionKey: string) {
  return async (
    request: FastifyRequest<{ Params: { id: string } }>,
    reply: FastifyReply
  ) => {
    const currentUserId = request.user?.id
    if (!currentUserId) return reply.code(401).send({ error: 'unauthenticated' })

    if (request.params?.id === currentUserId) return // owner
    const allowed = await hasPermission(currentUserId, permissionKey)
    if (!allowed) {
      return reply.code(403).send({ error: 'forbidden', missing: permissionKey })
    }
  }
}
