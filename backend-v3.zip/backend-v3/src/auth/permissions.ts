import prisma from '@/lib/prisma.js'
import { Effect } from '@prisma/client'

export async function hasPermission(userId: string, key: string) {
  const perm = await prisma.permission.findUnique({ where: { key } })
  if (!perm) return false

  // 1) excepciones por usuario (DENY gana)
  const up = await prisma.userPermission.findUnique({
    where: { userId_permissionId: { userId, permissionId: perm.id } }
  })
  if (up?.effect === Effect.DENY) return false
  if (up?.effect === Effect.ALLOW) return true

  // 2) vía roles
  const count = await prisma.userRole.count({
    where: {
      userId,
      role: {
        enabled: true,
        perms: { some: { permissionId: perm.id } }
      }
    }
  })
  return count > 0
}
