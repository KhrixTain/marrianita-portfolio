import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify'
import bcrypt from 'bcryptjs'
import prisma from '@/lib/prisma.js'
import { signAccessToken } from '@/auth/jwt.js'
// Opción A: si usas preHandler suelto

// Si decoraste app.auth en un plugin, podés usarlo en lugar de authPreHandler:
// app.get('/me', { preHandler: app.auth }, ...)

type LoginBody = { email?: string; password?: string }

export default async function authRoutes(app: FastifyInstance) {
  // POST /auth/login
  app.post<{ Body: LoginBody }>('/auth/login', async (req, reply) => {
    const { email, password } = req.body ?? {}
    if (!email || !password) {
      return reply.code(400).send({ error: 'missing_credentials' })
    }

    const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } })
    if (!user || !user.enabled) {
      return reply.code(401).send({ error: 'invalid_credentials' })
    }

    const ok = await bcrypt.compare(password, user.passwordHash)
    if (!ok) {
      return reply.code(401).send({ error: 'invalid_credentials' })
    }

    const accessToken = signAccessToken({ sub: user.id, email: user.email })

    return reply.send({
      accessToken,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        enabled: user.enabled,
      },
    })
  })

  // POST /auth/logout  (no cookies → 204 sin cuerpo)
  app.post('/auth/logout', async (_req, reply) => {
    return reply.code(204).send()
  })

  // GET /auth/me  -> requiere access en Authorization
  app.get('/auth/me', async (req, reply) => {
    const me = await prisma.user.findUnique({
      where: { id: req.user!.id },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        enabled: true,
        createdAt: true,
        updatedAt: true,
      },
    })
    if (!me) return reply.code(404).send({ error: 'not_found' })
    return reply.send(me)
  })
}
