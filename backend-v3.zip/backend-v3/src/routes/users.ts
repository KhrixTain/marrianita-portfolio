import type { FastifyInstance } from 'fastify'
import prisma from '@/lib/prisma.js'
import { requirePermission, requireSelfOr } from '@/auth/requirePermission'

// —— Plugin de rutas —— //
export default async function usersRoutes(app: FastifyInstance) {
  // Si registraste un preHandler global (p.ej. app.addHook('preHandler', app.auth)),
  // ya tendrás request.user. Si no, añadí tu preHandler de auth aquí primero.
  // Ejemplo (si expusiste app.auth desde un plugin):
  // const auth = app.auth

  // GET /users  → user:read
  app.get(
    '/users',
    {
      preHandler: requirePermission('user:read'),
    },
    async (_req, reply) => {
      const users = await prisma.user.findMany({
        select: { id: true, email: true, firstName: true, lastName: true, enabled: true, createdAt: true },
      })
      return reply.send(users)
    }
  )

  // GET /users/:id  → owner OR user:read
  app.get<{ Params: { id: string } }>(
    '/users/:id',
    {
      preHandler: requireSelfOr('user:read'),
    },
    async (req, reply) => {
      const u = await prisma.user.findUnique({
        where: { id: req.params.id },
        select: { id: true, email: true, firstName: true, lastName: true, enabled: true, createdAt: true },
      })
      if (!u) return reply.code(404).send({ error: 'not_found' })
      return reply.send(u)
    }
  )

  // POST /users  → user:create
  app.post<{ Body: { email: string; firstName: string; lastName: string; passwordHash: string; enabled?: boolean } }>(
    '/users',
    {
      preHandler: requirePermission('user:create'),
    },
    async (req, reply) => {
      const { email, firstName, lastName, passwordHash, enabled = true } = req.body
      const created = await prisma.user.create({
        data: { email: String(email).toLowerCase(), firstName, lastName, passwordHash, enabled },
        select: { id: true, email: true, firstName: true, lastName: true, enabled: true, createdAt: true },
      })
      return reply.code(201).send(created)
    }
  )

  // PATCH /users/:id  → owner OR user:update
  app.patch<{ Params: { id: string }; Body: { firstName?: string; lastName?: string; enabled?: boolean } }>(
    '/users/:id',
    {
      preHandler: requireSelfOr('user:update'),
    },
    async (req, reply) => {
      const { firstName, lastName, enabled } = req.body
      try {
        const updated = await prisma.user.update({
          where: { id: req.params.id },
          data: { firstName, lastName, enabled },
          select: { id: true, email: true, firstName: true, lastName: true, enabled: true, updatedAt: true },
        })
        return reply.send(updated)
      } catch {
        return reply.code(404).send({ error: 'not_found' })
      }
    }
  )

  // DELETE /users/:id  → user:delete
  app.delete<{ Params: { id: string } }>(
    '/users/:id',
    {
      preHandler: requirePermission('user:delete'),
    },
    async (req, reply) => {
      try {
        await prisma.user.delete({ where: { id: req.params.id } })
        return reply.code(204).send()
      } catch {
        return reply.code(404).send({ error: 'not_found' })
      }
    }
  )
}
