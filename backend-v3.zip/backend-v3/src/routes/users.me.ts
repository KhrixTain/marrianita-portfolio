import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify'
import prisma from '@/lib/prisma.js'

type PatchBody = { firstName?: string; lastName?: string }

export default async function usersMeRoutes(app: FastifyInstance) {
  // GET /users/me → ver mi perfil
  app.get(
    '/users/me',
    async (req: FastifyRequest, reply: FastifyReply) => {
      const userId = req.user?.id
      if (!userId) return reply.code(401).send({ error: 'unauthenticated' })

      const me = await prisma.user.findUnique({
        where: { id: userId },
        select: {
          id: true, email: true, firstName: true, lastName: true,
          enabled: true, createdAt: true, updatedAt: true,
        },
      })
      if (!me) return reply.code(404).send({ error: 'not_found' })
      return reply.send(me)
    }
  )

  // PATCH /users/me → actualizar mi perfil (campos seguros)
  app.patch<{ Body: PatchBody }>(
    '/users/me',
    async (req, reply) => {
      const userId = req.user?.id
      if (!userId) return reply.code(401).send({ error: 'unauthenticated' })

      const { firstName, lastName } = req.body ?? {}
      const updated = await prisma.user.update({
        where: { id: userId },
        data: { firstName, lastName },
        select: {
          id: true, email: true, firstName: true, lastName: true,
          enabled: true, updatedAt: true,
        },
      })
      return reply.send(updated)
    }
  )
}
