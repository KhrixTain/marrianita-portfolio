// src/routes/health.ts
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify'
import prisma from '@/lib/prisma.js'
import { env } from '@/env.js'

const TIMEOUT_MS = 1_500
const withTimeout = <T,>(p: Promise<T>, ms = TIMEOUT_MS) =>
  Promise.race([p, new Promise<never>((_, r) => setTimeout(() => r(new Error('timeout')), ms))])

async function dbPing() {
  const t0 = performance.now()
  await withTimeout(prisma.$queryRaw`SELECT 1`)
  return { status: 'UP' as const, latencyMs: Math.round(performance.now() - t0) }
}

export async function live(_req: FastifyRequest, reply: FastifyReply) {
  reply.header('Cache-Control', 'no-store').code(200).send({ status: 'UP' })
}
export async function ready(_req: FastifyRequest, reply: FastifyReply) {
  try {
    const db = await dbPing()
    reply.header('Cache-Control', 'no-store').code(200).send({ status: 'UP', db })
  } catch (err) {
    reply.header('Cache-Control', 'no-store').code(503).send({ status: 'DOWN', db: { status: 'DOWN' }, error: (err as Error).message })
  }
}
export async function health(_req: FastifyRequest, reply: FastifyReply) {
  const uptimeSec = Math.floor(process.uptime())
  const startedAtMs = Date.now() - uptimeSec * 1000
  const meta = { uptimeSec, startedAtMs, startedAtISO: new Date(startedAtMs).toISOString(), env: env.NODE_ENV }
  try {
    const db = await dbPing()
    reply.header('Cache-Control', 'no-store').code(200).send({ status: 'UP', checks: { db }, meta })
  } catch (err) {
    reply.header('Cache-Control', 'no-store').code(503).send({ status: 'DOWN', checks: { db: { status: 'DOWN' } }, error: (err as Error).message, meta })
  }
}
