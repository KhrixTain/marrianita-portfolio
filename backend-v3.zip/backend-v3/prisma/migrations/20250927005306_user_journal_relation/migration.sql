-- CreateEnum
CREATE TYPE "public"."Currency" AS ENUM ('ARS');

-- CreateEnum
CREATE TYPE "public"."OperationKind" AS ENUM ('NORMAL', 'SALE_REVENUE', 'SALE_COST', 'ADJUSTMENT');

-- CreateEnum
CREATE TYPE "public"."LineSide" AS ENUM ('DEBIT', 'CREDIT');

-- CreateTable
CREATE TABLE "public"."JournalEntry" (
    "id" UUID NOT NULL,
    "number" SERIAL NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "description" TEXT,
    "createdById" UUID NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "JournalEntry_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."JournalOperation" (
    "id" UUID NOT NULL,
    "entryId" UUID NOT NULL,
    "order" INTEGER NOT NULL,
    "kind" "public"."OperationKind" NOT NULL DEFAULT 'NORMAL',
    "currency" "public"."Currency" NOT NULL DEFAULT 'ARS',

    CONSTRAINT "JournalOperation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."JournalLine" (
    "id" UUID NOT NULL,
    "operationId" UUID NOT NULL,
    "order" INTEGER NOT NULL,
    "accountId" UUID NOT NULL,
    "side" "public"."LineSide" NOT NULL,
    "amount" DECIMAL(20,2) NOT NULL,
    "description" TEXT,

    CONSTRAINT "JournalLine_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "JournalEntry_number_key" ON "public"."JournalEntry"("number");

-- CreateIndex
CREATE INDEX "JournalEntry_date_idx" ON "public"."JournalEntry"("date");

-- CreateIndex
CREATE UNIQUE INDEX "JournalOperation_entryId_order_key" ON "public"."JournalOperation"("entryId", "order");

-- CreateIndex
CREATE INDEX "JournalLine_accountId_idx" ON "public"."JournalLine"("accountId");

-- CreateIndex
CREATE UNIQUE INDEX "JournalLine_operationId_order_key" ON "public"."JournalLine"("operationId", "order");

-- AddForeignKey
ALTER TABLE "public"."JournalEntry" ADD CONSTRAINT "JournalEntry_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "public"."User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."JournalOperation" ADD CONSTRAINT "JournalOperation_entryId_fkey" FOREIGN KEY ("entryId") REFERENCES "public"."JournalEntry"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."JournalLine" ADD CONSTRAINT "JournalLine_operationId_fkey" FOREIGN KEY ("operationId") REFERENCES "public"."JournalOperation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."JournalLine" ADD CONSTRAINT "JournalLine_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES "public"."accounts"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
