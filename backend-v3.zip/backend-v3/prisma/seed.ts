import 'dotenv/config'
import { PrismaClient, Action, AccountType } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  await prisma.$transaction(async (tx) => {
    // ====== (1) Permisos CRUD user ======
    const permsData = [
      { key: 'user:create', resource: 'user', action: Action.CREATE, description: 'Crear usuario' },
      { key: 'user:read',   resource: 'user', action: Action.READ,   description: 'Leer usuario' },
      { key: 'user:update', resource: 'user', action: Action.UPDATE, description: 'Actualizar usuario' },
      { key: 'user:delete', resource: 'user', action: Action.DELETE, description: 'Eliminar usuario' },
    ]
    const permissions = []
    for (const p of permsData) {
      const perm = await tx.permission.upsert({
        where: { key: p.key },
        update: { description: p.description },
        create: p,
      })
      permissions.push(perm)
    }

    // ====== (2) Rol admin ======
    const adminRole = await tx.role.upsert({
      where: { slug: 'admin' },
      update: { enabled: true },
      create: {
        slug: 'admin',
        name: 'Administrator',
        description: 'Full access to user management',
        enabled: true,
      },
    })

    // ====== (3) Vincular rol ↔ permisos ======
    for (const perm of permissions) {
      await tx.rolePermission.upsert({
        where: { roleId_permissionId: { roleId: adminRole.id, permissionId: perm.id } },
        update: {},
        create: { roleId: adminRole.id, permissionId: perm.id },
      })
    }

    // ====== (4) Usuario inicial ======
    const email = 'admin@example.com'.toLowerCase()
    const passwordHash = await bcrypt.hash('changeme123', 12)
    const user = await tx.user.upsert({
      where: { email },
      update: {},
      create: { email, firstName: 'Admin', lastName: 'User', passwordHash, enabled: true },
    })

    // ====== (5) Asignar rol admin al usuario ======
    await tx.userRole.upsert({
      where: { userId_roleId: { userId: user.id, roleId: adminRole.id } },
      update: {},
      create: { userId: user.id, roleId: adminRole.id },
    })

    // ====== (6) Plan de Cuentas (árbol) ======
    const rawAccounts = [
      // Activo
      { code: '100', name: 'Activo',                      r: 0, t: 'Ac' },
      { code: '110', name: 'Caja y Bancos',               r: 0, t: 'Ac' },
      { code: '111', name: 'Caja',                        r: 1, t: 'Ac' },
      { code: '112', name: 'Banco plazo fijo',            r: 1, t: 'Ac' },
      { code: '113', name: 'Banco c/c',                   r: 1, t: 'Ac' },
      { code: '120', name: 'Creditos',                    r: 0, t: 'Ac' },
      { code: '121', name: 'Deudores por Ventas',         r: 1, t: 'Ac' },
      { code: '122', name: 'Documentos a Cobrar',         r: 1, t: 'Ac' },
      { code: '123', name: 'Valores a Depositar',         r: 1, t: 'Ac' },
      { code: '130', name: 'Bienes de cambio',            r: 0, t: 'Ac' },
      { code: '131', name: 'Mercaderias',                 r: 1, t: 'Ac' },
      { code: '140', name: 'Bienes de uso',               r: 0, t: 'Ac' },
      { code: '141', name: 'Inmuebles',                   r: 1, t: 'Ac' },
      { code: '142', name: 'Rodados',                     r: 1, t: 'Ac' },
      { code: '143', name: 'Instalaciones',               r: 1, t: 'Ac' },

      // Pasivo
      { code: '200', name: 'Pasivo',                      r: 0, t: 'Pa' },
      { code: '210', name: 'Deudas Comerciales',          r: 0, t: 'Pa' },
      { code: '211', name: 'Proveedores',                 r: 1, t: 'Pa' },
      { code: '212', name: 'Sueldos a Pagar',             r: 1, t: 'Pa' },
      { code: '220', name: 'Deudas Fiscales',             r: 0, t: 'Pa' },
      { code: '221', name: 'Impuestos a Pagar',           r: 1, t: 'Pa' },
      { code: '222', name: 'Moratorias',                  r: 1, t: 'Pa' },
      { code: '230', name: 'Prestamos Bancarios',         r: 1, t: 'Pa' },

      // Patrimonio
      { code: '300', name: 'Patrimonio',                  r: 0, t: 'Pm' },
      { code: '310', name: 'Capital',                     r: 1, t: 'Pm' },
      { code: '320', name: 'Resultados',                  r: 1, t: 'Pm' },

      // Ingresos (R+)
      { code: '400', name: 'Ingresos',                    r: 0, t: 'R+' },
      { code: '410', name: 'Ventas',                      r: 0, t: 'R+' }, // agrupador
      { code: '411', name: 'Ventas',                      r: 1, t: 'R+' }, // hoja
      { code: '420', name: 'Otros ingresos',              r: 0, t: 'R+' },
      { code: '430', name: 'Intereses Ganados',           r: 1, t: 'R+' },

      // Egresos (R-)
      { code: '500', name: 'Egresos',                     r: 0, t: 'R-' },
      { code: '510', name: 'Costo de Mercadería Vendida', r: 1, t: 'R-' },
      { code: '520', name: 'Impuestos',                   r: 1, t: 'R-' },
      { code: '530', name: 'Sueldos',                     r: 1, t: 'R-' },
      { code: '540', name: 'Intereses',                   r: 1, t: 'R-' },
      { code: '550', name: 'Alquileres',                  r: 1, t: 'R-' },
    ] as const

    // Mapeo de tipo contable → enum
    const mapType = (t: string): AccountType => {
      switch (t) {
        case 'R-': return AccountType.R_NEG
        case 'R+': return AccountType.R_POS
        case 'Ac': return AccountType.AC
        case 'Pa': return AccountType.PA
        case 'Pm': return AccountType.PM
        default: throw new Error(`Tipo desconocido: ${t}`)
      }
    }

    const createdByCode = new Map<string, { id: string }>()
    const accountsSorted = [...rawAccounts].sort((a, b) => a.code.localeCompare(b.code))

    for (const a of accountsSorted) {
      const codeNum = Number(a.code)
      const parentCode =
        codeNum % 100 === 0 ? null
        : codeNum % 10 === 0 ? String(Math.floor(codeNum / 100) * 100).padStart(3, '0')
        : String(Math.floor(codeNum / 10) * 10).padStart(3, '0')

      const parent = parentCode ? createdByCode.get(parentCode) : null

      const row = await tx.account.upsert({
        where: { code: a.code },
        update: {
          name: a.name,
          receivesBalance: a.r === 1,
          type: mapType(a.t),
          parentId: parent?.id ?? null,
        },
        create: {
          code: a.code,
          name: a.name,
          receivesBalance: a.r === 1,
          type: mapType(a.t),
          parentId: parent?.id ?? null,
        },
        select: { id: true, code: true },
      })

      createdByCode.set(a.code, { id: row.id })
    }

    console.log('✅ Seed OK')
    console.table({
      user: email,
      role: adminRole.slug,
      perms: permissions.map(p => p.key).join(', '),
      accounts: rawAccounts.length,
    })
  })
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
